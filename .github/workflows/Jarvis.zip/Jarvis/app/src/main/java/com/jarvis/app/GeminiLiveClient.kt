package com.jarvis.app

import android.util.Base64
import okhttp3.*
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Gemini Live API over WebSocket: audio in -> audio out, with function calling. */
class GeminiLiveClient(private val apiKey: String, private val model: String, private val voice: String, private val extra: String, private val l: Listener) {
    interface Listener {
        fun onReady()
        fun onAudio(pcm24k: ByteArray)
        fun onInterrupted()
        fun onText(who: String, text: String)
        fun onToolCall(id: String, name: String, args: JSONObject)
        fun onClosed(reason: String)
    }

    private val http = OkHttpClient.Builder().pingInterval(20, TimeUnit.SECONDS).readTimeout(0, TimeUnit.MILLISECONDS).build()
    private var ws: WebSocket? = null

    fun connect() {
        val url = "wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        ws = http.newWebSocket(Request.Builder().url(url).build(), object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) { webSocket.send(setup().toString()) }
            override fun onMessage(webSocket: WebSocket, text: String) = handle(text)
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) = handle(bytes.utf8())
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) = l.onClosed("$code $reason")
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) = l.onClosed(t.message ?: "error")
        })
    }

    private fun setup(): JSONObject {
        val sys = "You are Jarvis, a fast, helpful voice assistant living on the user's Android phone. " +
            "Reply briefly, in the same language the user speaks (Hindi or English). " +
            "Use the provided tools to control the phone when asked, then confirm in one short sentence. " + extra
        return JSONObject().put("setup", JSONObject()
            .put("model", "models/$model")
            .put("generationConfig", JSONObject().put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
            .put("inputAudioTranscription", JSONObject())
            .put("outputAudioTranscription", JSONObject())
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("tools", JSONArray().put(JSONObject().put("functionDeclarations", PhoneTools.declarations()))))
    }

    private fun handle(text: String) {
        val j = JSONObject(text)
        if (j.has("setupComplete")) l.onReady()
        j.optJSONObject("serverContent")?.let { sc ->
            if (sc.optBoolean("interrupted")) l.onInterrupted()
            sc.optJSONObject("inputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }?.let { l.onText("You", it) }
            sc.optJSONObject("outputTranscription")?.optString("text")?.takeIf { it.isNotEmpty() }?.let { l.onText("Jarvis", it) }
            sc.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                for (i in 0 until parts.length()) {
                    parts.getJSONObject(i).optJSONObject("inlineData")?.optString("data")?.takeIf { it.isNotEmpty() }
                        ?.let { l.onAudio(Base64.decode(it, Base64.DEFAULT)) }
                }
            }
        }
        j.optJSONObject("toolCall")?.optJSONArray("functionCalls")?.let { calls ->
            for (i in 0 until calls.length()) {
                val c = calls.getJSONObject(i)
                l.onToolCall(c.optString("id"), c.getString("name"), c.optJSONObject("args") ?: JSONObject())
            }
        }
    }

    fun sendAudio(pcm16k: ByteArray) {
        val m = JSONObject().put("realtimeInput", JSONObject().put("audio", JSONObject()
            .put("data", Base64.encodeToString(pcm16k, Base64.NO_WRAP)).put("mimeType", "audio/pcm;rate=16000")))
        ws?.send(m.toString())
    }

    fun sendToolResponse(id: String, name: String, result: String) {
        val m = JSONObject().put("toolResponse", JSONObject().put("functionResponses", JSONArray().put(
            JSONObject().put("id", id).put("name", name).put("response", JSONObject().put("result", result)))))
        ws?.send(m.toString())
    }

    fun close() { ws?.close(1000, "bye"); http.dispatcher.executorService.shutdown() }
}
