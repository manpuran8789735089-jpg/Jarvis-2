package com.jarvis.app

import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class JarvisAccessibilityService : AccessibilityService() {
    companion object { @Volatile var instance: JarvisAccessibilityService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun clickable(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
        var x = n
        while (x != null && !x.isClickable) x = x.parent
        return x
    }

    /** Taps the first on-screen element whose text or description contains [t]. */
    fun clickText(t: String): Boolean {
        val root = rootInActiveWindow ?: return false
        for (n in root.findAccessibilityNodeInfosByText(t)) {
            if (clickable(n)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) return true
        }
        return false
    }

    fun typeText(t: String): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun scroll(down: Boolean): Boolean {
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isScrollable) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        val s = find(rootInActiveWindow) ?: return false
        return s.performAction(if (down) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    /** Flips the first switch/toggle whose state differs from [want] (used for WiFi/Bluetooth panels). */
    fun setFirstSwitch(want: Boolean): Boolean {
        fun find(n: AccessibilityNodeInfo?): AccessibilityNodeInfo? {
            if (n == null) return null
            if (n.isCheckable && n.isChecked != want) return n
            for (i in 0 until n.childCount) find(n.getChild(i))?.let { return it }
            return null
        }
        val s = find(rootInActiveWindow) ?: return false
        return clickable(s)?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
    }

    fun readScreen(): String {
        val sb = StringBuilder()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || sb.length > 1500) return
            (n.text ?: n.contentDescription)?.let { sb.append(it).append(" | ") }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(rootInActiveWindow)
        return sb.toString().ifBlank { "screen is empty" }
    }

    fun nav(action: String): Boolean = performGlobalAction(when (action) {
        "home" -> GLOBAL_ACTION_HOME
        "back" -> GLOBAL_ACTION_BACK
        "recents" -> GLOBAL_ACTION_RECENTS
        "screenshot" -> GLOBAL_ACTION_TAKE_SCREENSHOT
        "lock" -> GLOBAL_ACTION_LOCK_SCREEN
        "quicksettings" -> GLOBAL_ACTION_QUICK_SETTINGS
        else -> GLOBAL_ACTION_NOTIFICATIONS
    })

    fun enter(): Boolean {
        val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        return if (android.os.Build.VERSION.SDK_INT >= 30)
            f.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) else false
    }
}
