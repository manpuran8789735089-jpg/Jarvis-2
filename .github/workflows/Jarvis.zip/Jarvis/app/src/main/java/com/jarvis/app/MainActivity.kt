package com.jarvis.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.*
import okhttp3.OkHttpClient
import okhttp3.Request

class MainActivity : Activity() {
    private lateinit var store: KeyStore
    private lateinit var keyInput: EditText
    private lateinit var modelInput: EditText
    private lateinit var instrInput: EditText
    private lateinit var spinner: Spinner
    private lateinit var voiceSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var perms: TextView
    private lateinit var transcript: TextView
    private val voices = listOf("Puck", "Charon", "Kore", "Fenrir", "Aoede", "Leda", "Orus", "Zephyr")

    private fun mask(k: String) = (if (k == store.active()) "✔ " else "") + k.take(6) + "••••" + k.takeLast(4)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        store = KeyStore(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 80, 40, 40) }
        setContentView(ScrollView(this).apply { addView(root) })
        fun text(t: String, size: Float = 16f) = TextView(this).apply { text = t; textSize = size; root.addView(this) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() }; root.addView(this) }

        text("Jarvis", 28f)
        keyInput = EditText(this).apply { hint = "Gemini API key यहाँ डालें"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD; root.addView(this) }
        btn("💾 Save") { val k = keyInput.text.toString().trim(); if (k.isNotEmpty()) { store.save(k); keyInput.setText(""); refresh(); say("Key save हो गई") } }
        btn("🔍 Check") { checkKey() }
        text("Saved keys:")
        spinner = Spinner(this).also { root.addView(it) }
        btn("✅ Activate (चुनी हुई key)") { selected()?.let { store.activate(it); refresh(); say("Key active है") } ?: say("पहले key save करें") }
        btn("🗑 Delete") { selected()?.let { store.delete(it); refresh(); say("Delete हो गई") } }

        text("\nSettings", 20f)
        text("Model:")
        modelInput = EditText(this).apply { setText(store.model); root.addView(this) }
        text("Voice:")
        voiceSpinner = Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, voices); setSelection(voices.indexOf(store.voice).coerceAtLeast(0)); root.addView(this) }
        text("Extra instructions (वैकल्पिक):")
        instrInput = EditText(this).apply { setText(store.instruction); hint = "जैसे: मुझे भैया बुलाओ"; minLines = 2; root.addView(this) }

        text("\nPermissions", 20f)
        perms = text("")
        btn("1. Mic / Call / SMS / Contacts / Bluetooth / Notification") { askRuntime() }
        btn("2. Display over other apps") { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        btn("3. Accessibility (Jarvis Control चालू करें)") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn("4. Modify system settings (brightness)") { startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))) }

        text("\nJarvis", 20f)
        btn("▶ Start Jarvis") { start() }
        btn("⏹ Stop Jarvis") { stopService(Intent(this, JarvisService::class.java)); say("बंद") }
        status = text("")
        text("\nबातचीत:", 18f)
        transcript = text("")
        refresh()
    }

    override fun onResume() {
        super.onResume(); updatePerms()
        Bus.onText = { who, t -> runOnUiThread { transcript.text = (transcript.text.toString() + (if (who == "You") "\n🧑 " else "\n🤖 ") + t).takeLast(1500) } }
    }
    override fun onPause() { Bus.onText = null; super.onPause() }

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun updatePerms() {
        val rows = listOf(
            "Mic" to granted(Manifest.permission.RECORD_AUDIO), "Call" to granted(Manifest.permission.CALL_PHONE),
            "SMS" to granted(Manifest.permission.SEND_SMS), "Contacts" to granted(Manifest.permission.READ_CONTACTS),
            "Overlay" to Settings.canDrawOverlays(this), "Accessibility" to (JarvisAccessibilityService.instance != null),
            "System settings" to Settings.System.canWrite(this)
        )
        perms.text = rows.joinToString("   ") { (if (it.second) "✅ " else "❌ ") + it.first }
    }

    private fun selected(): String? = store.all().getOrNull(spinner.selectedItemPosition)
    private fun say(m: String) = runOnUiThread { status.text = m }
    private fun refresh() {
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, store.all().map { mask(it) })
    }

    private fun checkKey() {
        val k = keyInput.text.toString().trim().ifEmpty { selected() } ?: return say("कोई key नहीं मिली")
        say("चेक हो रहा है…")
        Thread {
            val ok = try {
                OkHttpClient().newCall(Request.Builder().url("https://generativelanguage.googleapis.com/v1beta/models?key=$k").build())
                    .execute().use { it.code }
            } catch (e: Exception) { -1 }
            say(when (ok) { 200 -> "✅ Key सही है"; 400, 401, 403 -> "❌ Key गलत/बंद है ($ok)"; -1 -> "नेटवर्क error"; else -> "Error $ok" })
        }.start()
    }

    private fun askRuntime() {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 31) p.add(Manifest.permission.BLUETOOTH_CONNECT)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }
    override fun onRequestPermissionsResult(rc: Int, p: Array<out String>, r: IntArray) { super.onRequestPermissionsResult(rc, p, r); updatePerms() }

    private fun start() {
        store.model = modelInput.text.toString().trim().ifEmpty { KeyStore.DEFAULT_MODEL }
        store.voice = voices[voiceSpinner.selectedItemPosition]
        store.instruction = instrInput.text.toString().trim()
        if (store.active() == null) return say("पहले key Activate करें")
        if (!granted(Manifest.permission.RECORD_AUDIO)) return say("पहले Mic permission दें")
        startForegroundService(Intent(this, JarvisService::class.java))
        say("Jarvis चालू — बोलिए! (J बटन: टैप=म्यूट, लॉन्ग-प्रेस=बंद)")
    }
}
