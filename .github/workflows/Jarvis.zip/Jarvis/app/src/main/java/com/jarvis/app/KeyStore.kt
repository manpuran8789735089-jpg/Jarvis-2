package com.jarvis.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API keys encrypted on-device. Supports many saved keys + one active key. */
class KeyStore(ctx: Context) {
    private val sp: SharedPreferences = EncryptedSharedPreferences.create(
        ctx, "jarvis_keys",
        MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun all(): List<String> = (sp.getString("keys", "") ?: "").split("\n").filter { it.isNotBlank() }
    fun save(key: String) { val l = all().toMutableList(); if (key !in l) l.add(key); sp.edit().putString("keys", l.joinToString("\n")).apply() }
    fun delete(key: String) {
        sp.edit().putString("keys", all().filter { it != key }.joinToString("\n")).apply()
        if (active() == key) sp.edit().remove("active").apply()
    }
    fun activate(key: String) { sp.edit().putString("active", key).apply() }
    fun active(): String? = sp.getString("active", null)
    var model: String
        get() = sp.getString("model", DEFAULT_MODEL) ?: DEFAULT_MODEL
        set(v) { sp.edit().putString("model", v).apply() }

    var voice: String
        get() = sp.getString("voice", "Puck") ?: "Puck"
        set(v) { sp.edit().putString("voice", v).apply() }
    var instruction: String
        get() = sp.getString("instr", "") ?: ""
        set(v) { sp.edit().putString("instr", v).apply() }

    companion object {
        // Model names change over time - this is editable from the app screen.
        const val DEFAULT_MODEL = "gemini-2.5-flash-native-audio-preview-09-2025"
    }
}
