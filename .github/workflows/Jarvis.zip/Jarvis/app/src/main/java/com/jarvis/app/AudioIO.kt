package com.jarvis.app

import android.media.*
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.util.concurrent.Executors

/** Mic capture (16kHz PCM16 mono) and speaker playback (24kHz PCM16 mono). */
class AudioIO {
    @Volatile private var running = false
    @Volatile var muted = false
    fun toggleMute(): Boolean { muted = !muted; return muted }
    private var rec: AudioRecord? = null
    private var track: AudioTrack? = null
    private val player = Executors.newSingleThreadExecutor()

    @Suppress("MissingPermission")
    fun start(onChunk: (ByteArray) -> Unit) {
        val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val r = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, 16000,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 4096) * 2)
        if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(r.audioSessionId)?.enabled = true
        if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(r.audioSessionId)?.enabled = true
        rec = r

        val outMin = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(maxOf(outMin, 8192) * 2)
            .setTransferMode(AudioTrack.MODE_STREAM).build().also { it.play() }

        running = true
        r.startRecording()
        Thread {
            val buf = ByteArray(1280) // ~40 ms
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0 && !muted) onChunk(buf.copyOf(n))
            }
        }.start()
    }

    fun play(pcm: ByteArray) { player.execute { track?.write(pcm, 0, pcm.size) } }

    /** User interrupted the model: drop queued speech immediately. */
    fun flush() { track?.let { it.pause(); it.flush(); it.play() } }

    fun stop() {
        running = false
        runCatching { rec?.stop(); rec?.release() }
        runCatching { track?.stop(); track?.release() }
        player.shutdownNow()
    }
}
