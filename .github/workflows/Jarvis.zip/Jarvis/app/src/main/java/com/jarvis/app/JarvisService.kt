package com.jarvis.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import org.json.JSONObject

/** Live transcript channel to the main screen. */
object Bus { @Volatile var onText: ((String, String) -> Unit)? = null }

class JarvisService : Service(), GeminiLiveClient.Listener {
    private var client: GeminiLiveClient? = null
    private var audio: AudioIO? = null
    private var overlay: TextView? = null
    @Volatile private var stopping = false
    private var retries = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startFg()
        stopping = false; retries = 0
        if (KeyStore(this).active() == null) { stopSelf(); return START_NOT_STICKY }
        connect(); showOverlay()
        return START_STICKY
    }

    private fun connect() {
        val ks = KeyStore(this)
        val key = ks.active() ?: run { stopSelf(); return }
        client = GeminiLiveClient(key, ks.model, ks.voice, ks.instruction, this).also { it.connect() }
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("jarvis", "Jarvis", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "jarvis").setContentTitle("Jarvis सुन रहा है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    /** Floating button: tap = mute/unmute mic, long-press = stop Jarvis. */
    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this) || overlay != null) return
        val tv = TextView(this).apply {
            text = "J"; textSize = 22f; setTextColor(Color.WHITE); setBackgroundColor(Color.parseColor("#CC1565C0"))
            gravity = Gravity.CENTER
            setOnClickListener { text = if (audio?.toggleMute() == true) "M" else "J" }
            setOnLongClickListener { stopSelf(); true }
        }
        val lp = WindowManager.LayoutParams(140, 140, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.END or Gravity.CENTER_VERTICAL }
        (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(tv, lp)
        overlay = tv
    }

    // ---- Gemini callbacks ----
    override fun onReady() {
        retries = 0
        audio?.stop()
        audio = AudioIO().also { a -> a.start { chunk -> client?.sendAudio(chunk) } }
    }
    override fun onAudio(pcm24k: ByteArray) { audio?.play(pcm24k) }
    override fun onInterrupted() { audio?.flush() }
    override fun onText(who: String, text: String) { Bus.onText?.invoke(who, text) }
    override fun onToolCall(id: String, name: String, args: JSONObject) {
        Thread {
            val result = try { PhoneTools.run(this, name, args) } catch (e: Exception) { "error: ${e.message}" }
            client?.sendToolResponse(id, name, result)
        }.start()
    }
    override fun onClosed(reason: String) {
        if (stopping) return
        audio?.stop(); audio = null
        if (retries++ < 3) Handler(Looper.getMainLooper()).postDelayed({ if (!stopping) connect() }, 2000)
        else { Bus.onText?.invoke("Jarvis", "कनेक्शन टूट गया: $reason"); stopSelf() }
    }

    override fun onDestroy() {
        stopping = true
        audio?.stop(); client?.close()
        overlay?.let { runCatching { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } }
        super.onDestroy()
    }
}
