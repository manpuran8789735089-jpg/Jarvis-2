package com.jarvis.app

import android.bluetooth.BluetoothManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import android.telephony.SmsManager
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Everything Gemini is allowed to do on the phone. Add a tool = add to declarations() + run(). */
object PhoneTools {
    private fun tool(name: String, desc: String, vararg p: Triple<String, String, String>): JSONObject {
        val props = JSONObject(); p.forEach { props.put(it.first, JSONObject().put("type", it.second).put("description", it.third)) }
        val o = JSONObject().put("name", name).put("description", desc)
        if (p.isNotEmpty()) o.put("parameters", JSONObject().put("type", "object").put("properties", props)
            .put("required", JSONArray(p.map { it.first })))
        return o
    }
    private fun s(n: String, d: String) = Triple(n, "string", d)
    private fun b(n: String, d: String) = Triple(n, "boolean", d)
    private fun i(n: String, d: String) = Triple(n, "integer", d)

    fun declarations(): JSONArray = JSONArray()
        .put(tool("open_app", "Open an installed app by its name", s("app_name", "App name, e.g. WhatsApp, Camera")))
        .put(tool("set_wifi", "Turn WiFi on or off", b("enabled", "true=on")))
        .put(tool("set_bluetooth", "Turn Bluetooth on or off", b("enabled", "true=on")))
        .put(tool("set_location", "Turn GPS/location on or off", b("enabled", "true=on")))
        .put(tool("open_settings", "Open a settings page", s("page", "wifi, bluetooth, location, mobile_data, airplane, display, sound, battery, apps")))
        .put(tool("send_whatsapp", "Send a WhatsApp message", s("phone", "Number with country code, digits only"), s("message", "Message text")))
        .put(tool("send_sms", "Send an SMS", s("number", "Phone number"), s("message", "Message text")))
        .put(tool("youtube_search", "Search on YouTube", s("query", "Search text")))
        .put(tool("media_control", "Control music/video playback", s("action", "play_pause, next, previous or stop")))
        .put(tool("call_number", "Place a phone call to a number", s("number", "Phone number")))
        .put(tool("call_contact", "Call a saved contact by name", s("name", "Contact name")))
        .put(tool("set_alarm", "Set an alarm", i("hour", "0-23"), i("minute", "0-59"), s("label", "Alarm label")))
        .put(tool("set_timer", "Start a countdown timer", i("seconds", "Duration in seconds")))
        .put(tool("flashlight", "Turn flashlight on or off", b("enabled", "true=on")))
        .put(tool("set_volume", "Set media volume 0-100", i("percent", "0-100")))
        .put(tool("set_brightness", "Set screen brightness 0-100", i("percent", "0-100")))
        .put(tool("open_url", "Open a web link", s("url", "Full URL")))
        .put(tool("web_search", "Google search", s("query", "Search text")))
        .put(tool("navigate_to", "Open Google Maps navigation/search for a place", s("place", "Place or address")))
        .put(tool("battery_status", "Get battery level and charging state"))
        .put(tool("get_time", "Get current date and time"))
        .put(tool("set_clipboard", "Copy text to clipboard", s("text", "Text")))
        .put(tool("tap_text", "Tap an on-screen button/text in the current app", s("text", "Visible text or label")))
        .put(tool("type_text", "Type text into the focused input field", s("text", "Text to type")))
        .put(tool("press_enter", "Press Enter/Search on the keyboard"))
        .put(tool("scroll", "Scroll the current screen", s("direction", "up or down")))
        .put(tool("system_nav", "System navigation", s("action", "home, back, recents, notifications, quicksettings, screenshot or lock")))
        .put(tool("read_screen", "Read the visible text on the current screen"))

    private fun launch(c: Context, i: Intent) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i) }
    private fun acc() = JarvisAccessibilityService.instance
    private val noAcc = "Accessibility service is not enabled. Ask the user to enable Jarvis Control."
    private fun has(c: Context, p: String) = c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED

    fun run(c: Context, name: String, a: JSONObject): String {
        when (name) {
            "open_app" -> {
                val q = a.getString("app_name").lowercase()
                val pm = c.packageManager
                val app = pm.getInstalledApplications(0).firstOrNull { pm.getApplicationLabel(it).toString().lowercase().contains(q) }
                val i = app?.let { pm.getLaunchIntentForPackage(it.packageName) } ?: return "app not found"
                launch(c, i); return "opened"
            }
            "set_wifi" -> {
                val on = a.getBoolean("enabled")
                if (Build.VERSION.SDK_INT < 29) {
                    @Suppress("DEPRECATION") (c.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).isWifiEnabled = on
                    return "wifi ${if (on) "on" else "off"}"
                }
                launch(c, Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)); Thread.sleep(1500)
                return if (acc()?.setFirstSwitch(on) == true) "wifi toggled" else "opened wifi panel; toggle may need manual tap"
            }
            "set_bluetooth" -> {
                val on = a.getBoolean("enabled")
                if (Build.VERSION.SDK_INT < 33) {
                    val ad = (c.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter
                    @Suppress("DEPRECATION", "MissingPermission") if (on) ad.enable() else ad.disable()
                    return "bluetooth ${if (on) "on" else "off"}"
                }
                launch(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); Thread.sleep(1500)
                return if (acc()?.setFirstSwitch(on) == true) "bluetooth toggled" else "opened bluetooth settings; toggle may need manual tap"
            }
            "set_location" -> {
                launch(c, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); Thread.sleep(1500)
                return if (acc()?.setFirstSwitch(a.getBoolean("enabled")) == true) "location toggled" else "opened location settings"
            }
            "open_settings" -> {
                val act = when (a.getString("page")) {
                    "wifi" -> Settings.ACTION_WIFI_SETTINGS; "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS
                    "location" -> Settings.ACTION_LOCATION_SOURCE_SETTINGS; "mobile_data" -> Settings.ACTION_DATA_ROAMING_SETTINGS
                    "airplane" -> Settings.ACTION_AIRPLANE_MODE_SETTINGS; "display" -> Settings.ACTION_DISPLAY_SETTINGS
                    "sound" -> Settings.ACTION_SOUND_SETTINGS; "battery" -> Intent.ACTION_POWER_USAGE_SUMMARY
                    "apps" -> Settings.ACTION_APPLICATION_SETTINGS; else -> Settings.ACTION_SETTINGS
                }
                launch(c, Intent(act)); return "opened"
            }
            "send_whatsapp" -> {
                val u = Uri.parse("https://wa.me/${a.getString("phone")}?text=${Uri.encode(a.getString("message"))}")
                launch(c, Intent(Intent.ACTION_VIEW, u).setPackage("com.whatsapp")); Thread.sleep(3000)
                val s = acc() ?: return "chat opened, but $noAcc"
                return if (s.clickText("Send") || s.clickText("भेजें")) "sent" else "chat opened, send button not found"
            }
            "send_sms" -> {
                if (!has(c, android.Manifest.permission.SEND_SMS)) return "SMS permission not granted"
                val sm = if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
                val parts = sm.divideMessage(a.getString("message"))
                sm.sendMultipartTextMessage(a.getString("number"), null, parts, null, null); return "sms sent"
            }
            "youtube_search" -> {
                val u = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(a.getString("query"))}")
                launch(c, Intent(Intent.ACTION_VIEW, u).setPackage("com.google.android.youtube")); return "searching"
            }
            "media_control" -> {
                val code = when (a.getString("action")) {
                    "next" -> KeyEvent.KEYCODE_MEDIA_NEXT; "previous" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
                    "stop" -> KeyEvent.KEYCODE_MEDIA_STOP; else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
                }
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code)); am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
                return "ok"
            }
            "call_number" -> {
                if (!has(c, android.Manifest.permission.CALL_PHONE)) return "call permission not granted"
                launch(c, Intent(Intent.ACTION_CALL, Uri.parse("tel:${a.getString("number")}"))); return "calling"
            }
            "call_contact" -> {
                if (!has(c, android.Manifest.permission.READ_CONTACTS)) return "contacts permission not granted"
                val n = a.getString("name")
                val num = c.contentResolver.query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$n%"), null
                )?.use { if (it.moveToFirst()) it.getString(0) else null } ?: return "contact not found"
                return run(c, "call_number", JSONObject().put("number", num))
            }
            "set_alarm" -> {
                launch(c, Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, a.getInt("hour"))
                    .putExtra(AlarmClock.EXTRA_MINUTES, a.getInt("minute")).putExtra(AlarmClock.EXTRA_MESSAGE, a.optString("label", "Jarvis"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); return "alarm set"
            }
            "set_timer" -> {
                launch(c, Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, a.getInt("seconds"))
                    .putExtra(AlarmClock.EXTRA_SKIP_UI, true)); return "timer started"
            }
            "flashlight" -> {
                val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
                cm.setTorchMode(cm.cameraIdList[0], a.getBoolean("enabled")); return "ok"
            }
            "set_volume" -> {
                val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                am.setStreamVolume(AudioManager.STREAM_MUSIC, max * a.getInt("percent").coerceIn(0, 100) / 100, 0); return "ok"
            }
            "set_brightness" -> {
                if (!Settings.System.canWrite(c)) { launch(c, Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${c.packageName}"))); return "need 'Modify system settings' permission" }
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(c.contentResolver, Settings.System.SCREEN_BRIGHTNESS, a.getInt("percent").coerceIn(0, 100) * 255 / 100); return "ok"
            }
            "open_url" -> { launch(c, Intent(Intent.ACTION_VIEW, Uri.parse(a.getString("url")))); return "opened" }
            "web_search" -> { launch(c, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(a.getString("query"))}"))); return "searching" }
            "navigate_to" -> { launch(c, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(a.getString("place"))}"))); return "opened maps" }
            "battery_status" -> {
                val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                return "${bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)}%, charging=${bm.isCharging}"
            }
            "get_time" -> return SimpleDateFormat("EEEE, d MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
            "set_clipboard" -> {
                (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("jarvis", a.getString("text"))); return "copied"
            }
            "tap_text" -> return acc()?.let { if (it.clickText(a.getString("text"))) "tapped" else "not found on screen" } ?: noAcc
            "type_text" -> return acc()?.let { if (it.typeText(a.getString("text"))) "typed" else "no focused input" } ?: noAcc
            "press_enter" -> return acc()?.let { if (it.enter()) "done" else "no focused input" } ?: noAcc
            "scroll" -> return acc()?.let { if (it.scroll(a.getString("direction") == "down")) "scrolled" else "nothing to scroll" } ?: noAcc
            "system_nav" -> return acc()?.let { it.nav(a.getString("action")); "done" } ?: noAcc
            "read_screen" -> return acc()?.readScreen() ?: noAcc
        }
        return "unknown tool"
    }
}
