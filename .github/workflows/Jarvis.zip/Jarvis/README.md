# Jarvis (Android, Kotlin)
1. Android Studio -> Open -> Jarvis फ़ोल्डर -> Gradle sync -> फ़ोन पर Run।
2. ऐप में: API key -> Save -> Check -> Activate। फिर Voice/Model चुनें।
3. Permissions बटन 1-4 क्रम से दें (3 में "Jarvis Control" चालू करें)। ऊपर ✅/❌ से स्थिति दिखती है।
4. Start Jarvis दबाएँ और बोलें। J बटन: टैप = माइक म्यूट, लॉन्ग-प्रेस = बंद।
Tools: app खोलना, WiFi/BT/GPS, WhatsApp/SMS/Call/Contact, YouTube, music control, alarm/timer,
volume/brightness, maps, web search, battery/time, clipboard, tap/type/scroll/enter, screenshot/lock, screen पढ़ना।
